$(document).ready(function() {
    // Generate some random initial data if empty
    if (!localStorage.getItem('inventory')) {
        const dummyData = [
            { id: generateId(), name: "Mechanical Keyboard", sku: "KB-001", qty: 45, price: 120.00 },
            { id: generateId(), name: "Wireless Mouse", sku: "MS-002", qty: 120, price: 45.50 },
            { id: generateId(), name: "27-inch Monitor", sku: "MN-003", qty: 15, price: 350.00 }
        ];
        localStorage.setItem('inventory', JSON.stringify(dummyData));
    }

    let inventory = JSON.parse(localStorage.getItem('inventory')) || [];
    let editingId = null;

    // Helper: Generate unique ID
    function generateId() {
        return Math.random().toString(36).substr(2, 9);
    }

    // Helper: Format Currency
    function formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
    }

    // Render Table
    function renderTable() {
        const $tbody = $('#inventory-table tbody');
        $tbody.empty();
        
        let totalItems = 0;
        let totalValue = 0;

        if (inventory.length === 0) {
            $('#inventory-table').hide();
            $('#empty-state').show();
        } else {
            $('#inventory-table').show();
            $('#empty-state').hide();

            inventory.forEach(item => {
                const total = item.qty * item.price;
                totalItems += parseInt(item.qty);
                totalValue += total;

                const tr = `
                    <tr>
                        <td style="color: var(--text-secondary); font-family: monospace;">${item.sku}</td>
                        <td style="font-weight: 600;">${item.name}</td>
                        <td>${item.qty}</td>
                        <td>${formatCurrency(item.price)}</td>
                        <td>${formatCurrency(total)}</td>
                        <td class="actions">
                            <button class="btn edit edit-btn" data-id="${item.id}">Edit</button>
                            <button class="btn danger delete-btn" data-id="${item.id}">Del</button>
                        </td>
                    </tr>
                `;
                $tbody.append(tr);
            });
        }

        // Update Stats
        $('#total-items').text(totalItems);
        $('#total-value').text(formatCurrency(totalValue));
    }

    // Save to LocalStorage
    function saveInventory() {
        localStorage.setItem('inventory', JSON.stringify(inventory));
        renderTable();
    }

    // Handle Form Submit
    $('#inventory-form').on('submit', function(e) {
        e.preventDefault();
        
        const name = $('#item-name').val().trim();
        const sku = $('#item-sku').val().trim().toUpperCase();
        const qty = parseInt($('#item-qty').val());
        const price = parseFloat($('#item-price').val());

        if (editingId) {
            // Update existing
            const index = inventory.findIndex(item => item.id === editingId);
            if (index !== -1) {
                inventory[index] = { id: editingId, name, sku, qty, price };
            }
            editingId = null;
            $('#submit-btn').text('Add Item');
            $('#cancel-btn').hide();
        } else {
            // Add new
            inventory.push({ id: generateId(), name, sku, qty, price });
        }

        saveInventory();
        this.reset();
        $('#item-name').focus();
    });

    // Handle Edit
    $(document).on('click', '.edit-btn', function() {
        const id = $(this).data('id');
        const item = inventory.find(i => i.id === id);
        if (item) {
            $('#item-id').val(item.id);
            $('#item-name').val(item.name);
            $('#item-sku').val(item.sku);
            $('#item-qty').val(item.qty);
            $('#item-price').val(item.price);
            
            editingId = item.id;
            $('#submit-btn').text('Update Item');
            $('#cancel-btn').show();
        }
    });

    // Handle Delete
    $(document).on('click', '.delete-btn', function() {
        if (confirm("Are you sure you want to delete this item?")) {
            const id = $(this).data('id');
            inventory = inventory.filter(i => i.id !== id);
            saveInventory();
        }
    });

    // Handle Cancel Edit
    $('#cancel-btn').on('click', function() {
        editingId = null;
        $('#inventory-form')[0].reset();
        $('#submit-btn').text('Add Item');
        $(this).hide();
    });

    // Initial Render
    renderTable();
});
